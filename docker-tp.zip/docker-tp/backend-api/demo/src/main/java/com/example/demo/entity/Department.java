package com.example.demo.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "departments")          // ← FAIT la correspondance
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @OneToMany(mappedBy = "department")
    private List<Student> students;

    // getters / setters
    public Long getId()          { return id; }
    public void setId(Long id)   { this.id = id; }

    public String getName()      { return name; }
    public void setName(String n){ this.name = n; }

    public List<Student> getStudents() { return students; }
    public void setStudents(List<Student> s){ this.students = s; }
}

INSERT INTO departments (name) VALUES ('IRC'), ('ETI'), ('CGP');

INSERT INTO students (department_id, first_name, last_name) VALUES
  (1, 'Eli', 'Copter'),
  (2, 'Emma', 'Carena'),
  (2, 'Jack', 'Uzzi'),
  (3, 'Aude', 'Javel');
